<?php
header('Location: login/login_page.php');
exit;
?>
