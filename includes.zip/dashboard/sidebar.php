<div class="sidebar">
    <div class="sidebar-header">
        <h1>To-Do List</h1>
    </div>
    <ul class="sidebar-menu">
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="../daftar/daftar.php">Daftar</a></li>
    </ul>
</div>
